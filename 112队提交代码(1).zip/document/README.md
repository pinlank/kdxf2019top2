代码运行，依次运行mainscript.py--kbest.py--blend.py
代码存储文件夹已建好，data存放解压数据，submit存放结果
最终结果为end_755.csv


1）：mainscript.py
操作系统: GNU/Linux Ubuntu 18.04.3 LTS x86_64
语言环境: Python 3.6.8

第三方依赖版本: 

numpy 1.17.2
scipy 1.3.1
pandas 0.25.1
scikit-learn 0.21.3
lightgbm 2.2.3
PyWavelets 1.0.3

安装方式:

pip3 install numpy scipy pandas scikit-learn lightgbm PyWavelets 

脚本执行方式:

1切换目录至该文档所在目录
2执行 python3 ./code/mainscript.py

更多问题请联系: sknyqbcbw@gmail.com






2）：kbest.py
操作系统: Windows 10
语言环境: Python 3.6.5
第三方依赖版本: 

lgb version:  2.2.3
pandas version:  0.25.0
numpy version:  1.16.2
sklearn version:  0.21.3

脚本执行方式:
1切换目录至该文档所在目录
2执行 python3 ./code/mainscript.py


更多问题请联系: 1332102709@qq.com